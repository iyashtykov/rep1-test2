
{Check It!|assessment}(code-output-compare-3355749517)

